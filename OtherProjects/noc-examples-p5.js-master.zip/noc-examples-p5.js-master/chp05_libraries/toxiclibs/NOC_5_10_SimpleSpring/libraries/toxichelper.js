// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com

// Making it easier to use all these classes
// Maybe this is a bad idea?
const VerletPhysics2D = toxi.physics2d.VerletPhysics2D;
const GravityBehavior = toxi.physics2d.behaviors.GravityBehavior;
const AttractionBehavior = toxi.physics2d.behaviors.AttractionBehavior;
const VerletParticle2D = toxi.physics2d.VerletParticle2D;
const VerletSpring2D = toxi.physics2d.VerletSpring2D;
const VerletMinDistanceSpring2D = toxi.physics2d.VerletMinDistanceSpring2D;
const Vec2D = toxi.geom.Vec2D;
const Rect = toxi.geom.Rect;